// pages/index/index.js
const utils = require('../../utils/util.js');
const app = getApp()
Page({
  data: {
    username: '',
    tabs: ["我参与的", "我创建的"],
    TabCur: 0,
    meetingCreate: [{meetingtime: null}],
    meetingJoin: [{meetingtime: null}],
    meetingDeleteId : 0,
    meetingModalId : 0,
    meetingurl:'',
    admin : ''
  },
  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
    })
  },
  onLoad : function(options) {
    this.setData({
      username : options.username,
      admin : options.admin
    })
  },
  onShow : function(options)
  {
    var that = this
    if(this.data.admin == 1){
      wx.request({
        url: app.globalData.urlPath + '/meeting/findAll',
        method: 'GET',
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          that.setData({
            meetingCreate: res.data
          })
          var date
          var regex = /\//gi
          for (var i = 0; i < that.data.meetingCreate.length; i++) {
            date = new Date(that.data.meetingCreate[i].meetingtime)
            date = utils.formatTime(date).replace(regex, '-')
            that.setData({
              ["meetingCreate[" + i + "].meetingtime"]: date
            })
          }
        }
      })
    }
    else
    {
      wx.request({
        url: app.globalData.urlPath + '/meeting/all?username=' + this.data.username,
        method: 'GET',
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          that.setData({
            meetingCreate: res.data
          })
          var date
          var regex = /\//gi
          for (var i = 0; i < that.data.meetingCreate.length; i++) {
            date = new Date(that.data.meetingCreate[i].meetingtime)
            date = utils.formatTime(date).replace(regex, '-')
            that.setData({
              ["meetingCreate[" + i + "].meetingtime"]: date
            })
          }

        }
      })
    }
    wx.request({
      url: app.globalData.urlPath + '/join/request?username=' + this.data.username,
      method:'GET',
      header: {
        'content-type' : 'application/json'
      },
      success: function(res){
        that.setData({
          meetingJoin: res.data
        })
        var date
        var regex = /\//gi
        for (var i = 0; i < that.data.meetingJoin.length; i++) {
          date = new Date(that.data.meetingJoin[i].meetingtime)
          date = utils.formatTime(date).replace(regex, '-')
          that.setData({
            ["meetingJoin[" + i + "].meetingtime"]: date
          })
        }
      }
    })
  },
  toCreate : function() {
    wx.navigateTo({
      url: '../create/create?username=' + this.data.username,
    })
  },
  toJoin : function(){
    wx.navigateTo({
      url: '../joinid/joinid?username=' + this.data.username,
    })
  },
  cancel : function(e)
  {
    let that = this
    console.log(e.currentTarget.dataset.name )
    wx.showModal({
      title: '提示',
      content: '确定取消参加',
      success(res){
        if(res.confirm)
        {
          wx.request({
            url: app.globalData.urlPath + '/join/deleteByMeetingIdAndUsername?meetingid=' + e.currentTarget.dataset.name + '&username=' + that.data.username,
            method: 'POST',
            header: {
              'content-type': 'application/json'
            },
            success(res){
              that.onShow()
              wx.showToast({
                title: '取消成功',
                icon: 'success',
                duration:2000
              })
            }
          })
        }
      }
    })
  },
  del : function(e)
  {
    let that = this
    console.log(e.currentTarget.dataset.name)
    wx.showModal({
      title: '提示',
      content: '确定删除该会议？',
      success(res){
        if(res.confirm)
        {
          wx.request({
            url: app.globalData.urlPath + '/meeting/delete?meetingid=' + e.currentTarget.dataset.name,
            method:'POST',
            header: {
              'content-type': 'application/json'
            }
          })
          wx.request({
            url: app.globalData.urlPath + '/join/delete?meetingid=' + e.currentTarget.dataset.name,
            method: 'POST',
            header: {
              'content-type': 'application/json'
            },
            success(res) {
              that.onShow()
              wx.showToast({
                title: '删除成功',
                icon: 'success',
                duration: 2000
              })
            }
          })
        }
        
      }
    })
  },
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target,
      meetingModalId : e.currentTarget.dataset.meetingid,
      meetingurl: app.globalData.urlPath + '/join/QRcode?meetingid=' + e.currentTarget.dataset.meetingid
    })
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  qrModal(e){
    this.setData({
      qrName: e.currentTarget.dataset.target,
      meetingModalId: e.currentTarget.dataset.meetingid,
      meetingurl: app.globalData.urlPath + '/join/QRcode?meetingid=' + e.currentTarget.dataset.meetingid
    })
  },
  qrhide(e){
    this.setData({
      qrName: null
    })
  },
  excel : function(){
    console.log(this.data.meetingModalId)
    wx.downloadFile({
      url: app.globalData.urlPath + '/join/excel?meetingid=' + this.data.meetingModalId,
      success(res){
        
        wx.showToast({
          title: '正在打开',
          icon: 'success',
          duration: 2000
        })
        wx.openDocument({
          filePath: res.tempFilePath,
          fileType: "xls",
          success(res){
            console.log("打开成功")
          }
        })
      },
      fail(res)
      {
        wx.showToast({
          title: '下载失败',
          icon: 'loading',
          duration: 2000
        })
      }
    })
  },
  scan : function(){
    let that = this
    wx.scanCode({
      success(res) {
        wx.navigateTo({
          url: '../join/join?username=' + that.data.username + '&meetingid=' + res.result,
        })
      }
    })
  }
})