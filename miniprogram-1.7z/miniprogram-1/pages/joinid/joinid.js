const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username : '',
    meetingid : ''
  },

  bindMeetingIdInput : function(e)
  {
    this.setData({
      meetingid : e.detail.value
    })
  },
  
  onLoad: function (options) {
    this.setData({
      username: options.username
    })
  },
  toJoin: function(e){
    if(this.data.meetingid.length == 0)
    {
      wx.showToast({
        title: '会议号为空',
        icon: 'loading',
        duration : 1000
      })
    }
    else{
      var that = this
      wx.request({
        url: app.globalData.urlPath + '/meeting/id?meetingid=' + this.data.meetingid,
        method: 'GET',
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          if(res.data == null )
          {
           wx.showToast({
             title: '会议号出错',
             icon: 'loading',
             duration: 1000
           })
          }
          else
          {
            wx.navigateTo({
              url: '../join/join?username=' + that.data.username + '&meetingid=' + that.data.meetingid,
            })
          }
        }
      })
    }
  },
  back : function(e){
    wx.navigateBack({
      delta : 1
    })
  } 
})