const app = getApp()
Page({
  data: {
    username : '',
    password : '',
  },

  backToLogin : function (){
    wx.navigateBack({
      delta : 1,
      success:function(res){
        console.log("回到登陆")
      }
     })
    
  },

  usernameInput : function(e){
    this.setData({
      username: e.detail.value
    })
  },

  passwordInput : function(e){
    this.setData({
      password: e.detail.value
    })
  },
  
  toLogin : function(){
    var username = this.data.username
    var password = this.data.password
    var admin = this.data.admin
    if(username.length == 0){
      wx.showToast({
        title: '用户名为空',
        icon:'loading',
        duration:1000
      })
    }
    else if (password.length == 0){
      wx.showToast({
        title: '密码为空',
        icon: 'loading',
        duration: 1000
      })
    }
    else
    {
      wx.request({
        url: app.globalData.urlPath + '/register?username=' + username,
        method: 'GET',
        header: {
          'content-type': 'application/json'
        },
        success :function(res)
        {
          if(res.data == null)
          {
            wx.request({
              url: app.globalData.urlPath + '/register?username=' + username + '&password=' + password + '&admin=0' ,
              method: 'POST',
              header: {
                'content-type': 'application/json'
              },
              success: function (res) {
                wx.showToast({
                  title: '注册成功',
                  icon: 'success',
                  duration: 1000
                })
                wx.navigateTo({
                  url: '../login/login'
                })
              },
              fail: function (res) {
                wx.showToast({
                  title: '注册失败',
                  icon: 'fail',
                  duration: 1000
                })
              }
            })
          }
          else
          {
            wx.showToast({
              title: 'id已注册',
              icon: 'fail',
              duration: 1000
            })
          }
        },
        fail : function(res)
        {
        }
      })
    }
  }
})