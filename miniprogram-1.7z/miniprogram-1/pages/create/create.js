const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: '111',
    meetingname:'',
    meetingdesc:'',
    date : '2019-12-14',
    time : '00:00',
    room : '',
    name : 1,
    workplace : 1,  
    id : 1,
    phone : 1,
    jointime : 1,
    meetingtime : ''
  },
  bindTimeChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      time: e.detail.value
    })
  },
  bindDateChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  bindRoomInput: function(e){
    this.setData({
      room: e.detail.value ? '0' : '1'
    })
  },
  bindNameChange: function(e){
    this.setData({
      name: e.detail.value ? '0' : '1'
    })
  },
  bindWorkplaceChange: function (e) {
    this.setData({
      workplace: e.detail.value?'0': '1'
    })
  },
  bindIdentityCardChange: function (e) {
    this.setData({
      id: e.detail.value ? '0' : '1'
    })
  },
  bindPhoneChange: function (e) {
    this.setData({
      phone: e.detail.value ? '0' : '1'
    })
  },
  bindJoinTimeChange: function (e) {
    this.setData({
      jointime: e.detail.value ? '0' : '1'
    })
  },
  bindMeetingNameInput: function(e) {
    this.setData({
      meetingname: e.detail.value
    })
  },
  bindMeetingDescInput : function(e){
    this.setData({
      meetingdesc : e.detail.value
    })
  },
  submit: function(e){
    if(this.data.room == null)
    {
      wx.showToast({
        title: '会议地点不能为空',
        icon:'loading',
        duration:1000
      })
    }
    else if (this.data.meetingname == null)
    {
      wx.showToast({
        title: '会议名不能为空',
        icon: 'loading',
        duration: 1000
      })
    }
    else if (this.data.meetingdesc == null)
    {
      wx.showToast({
        title: '会议描述不能为空',
        icon: 'loading',
        duration: 1000
      })
    }
    else
    { 
      console.log(this.data.meetingdesc)
      console.log(this.data.meetingname)
      this.setData({
        meetingtime: this.data.date + ' ' + this.data.time + ':00'
      })
      wx.request({
        url: app.globalData.urlPath + '/meeting?username=' + this.data.username + '&meetingtime=' + this.data.meetingtime + '&name=' + this.data.name + '&workplace=' + this.data.name + '&identitycard=' + this.data.id + '&phone=' + this.data.phone + '&time=' + this.data.jointime + '&room=' + this.data.room +'&meetingname=' + this.data.meetingname + '&meetingdesc=' + this.data.meetingdesc,
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success : function(res){
          wx.navigateBack({
            delta: 1
          })
        }
      })
    }
  },
  back : function(e){
    wx.navigateBack({
      delta: 1
    })
  },
  onLoad : function(options) {
    this.setData({
      username : options.username
    })
  }
  
})