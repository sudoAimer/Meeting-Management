const app = getApp()
const utils = require('../../utils/util.js'); 
Page({

  data: {
    username : '',
    meetingid : '',
    name: '',
    workplace: '',
    identitycard: '',
    phone: '',
    time: '',
    information:[{}],
    meetingname: '',
    meetingdesc: '',
    room: '',
    meetingtime: ''
  },

  onLoad: function (options) {
    this.setData({
      username: options.username,
      meetingid: options.meetingid
    })
  },
  
  onShow: function (options) {
    let that = this
    wx.request({
      url: app.globalData.urlPath + '/meeting/id?meetingid=' + this.data.meetingid,
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        that.setData({
          information : res.data,
          meetingname : res.data.meetingname,
          meetingdesc : res.data.meetingdesc,
          room : res.data.room,
          meetingtime : res.data.meetingtime
        })
        console.log(that.data.information)
      }
    }) 
  },

  bindNameInput: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindWorkPlaceInput : function(e){
    this.setData({
      workplace : e.detail.value
    })
  },

  bindIdInput: function (e) {
    this.setData({
      identitycard: e.detail.value
    })
  },

  bindPhoneInput: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },

  bindJoinTimeInput: function (e) {
    this.setData({
      time: e.detail.value
    })
  },
  
  submit : function(e)
  {
    if(this.data.name == null && this.data.information.name == 1)
    {
      wx.showToast({
        title: '姓名不能为空',
        icon: 'loading',
        duration: 1000
      })
    }
    else if(this.data.workplace == null && this.data.information.workplace == 1)
    {
      wx.showToast({
        title: '工作场所不能为空',
        icon: 'loading',
        duration: 1000
      })
    }
    else if(this.data.identitycard == null && this.data.information.identitycard == 1)
    {
      wx.showToast({
        title: '身份证号不能为空',
        icon: 'loading',
        duration: 1000
      })
    } 
    else if(this.data.phone == null && this.data.information.phone == 1)
    {
      wx.showToast({
        title: '手机号不能为空',
        icon: 'loading',
        duration: 1000
      })
    }
    else if (this.data.time == null && this.data.time == 1)
    {
      wx.showToast({
        title: '参会时间不能为空',
        icon: 'loading',
        duration: 1000
      })
    }
  else
  {
      var that = this
      var date = new Date(this.data.meetingtime)
      var regex = /\//gi
      date = utils.formatTime(date).replace(regex,'-')
      wx.request({
        url: app.globalData.urlPath + '/join/insert?meetingid=' + this.data.meetingid + '&username=' + this.data.username + '&name=' + this.data.name + '&workplace=' + this.data.workplace + '&identitycard=' + this.data.identitycard + '&phone=' + this.data.phone + '&time=' + this.data.time + '&meetingname=' + this.data.meetingname + '&meetingdesc=' + this.data.meetingdesc + '&room=' + this.data.room + '&meetingtime=' + date,
        method: 'POST',
        header: {
          'content-type': 'application/json'
        },
        success: function(res){
          wx.showToast({
            title: '参会成功',
            icon: 'success',
            duration: 2000
          })
          wx.navigateTo({
            url: '../index/index?username=' + that.data.username,
          })
        }
      })
  }
  },
  back: function(){
    wx.navigateBack({
      delta: 1
    })
  }
})