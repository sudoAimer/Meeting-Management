const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username : '',
    password : '',
    admin: ''
  },

  toRegister: function (){
    wx.navigateTo({
      url: '../register/register',
    })
  },
  usernameInput: function(e){
    this.setData({
      username: e.detail.value
    })
  },

  passwordInput: function (e) {
    this.setData({
      password: e.detail.value
    })
  },
  
  userLogin: function(){
    if(this.data.username.length != 0 && this.data.password.length != 0)
    {
      var username = this.data.username
      var password = this.data.password
      let that = this
      wx.request({
        url: app.globalData.urlPath + '/register?username=' + username,
        method: 'GET',
        header: {
          'content-type': 'application/json'
        },
        success : function(res){
          if(res.data == null){
            wx.showToast({
              title : '未注册',
              icon: 'loading',
              duration : 1000
            })
          }
          else
          {
            if(password == res.data.password)
            {
              that.setData({
                admin : res.data.admin
              })
              wx.navigateTo({
                url: '../index/index?username=' + username + '&admin=' + that.data.admin,
              })
            }
            else
            {
              wx.showToast({
                title : '密码错误',
                icon : 'loading',
                duration : 1000
              })
            }
          }
        },
        fail : function(res){

        }
      })
    }
    else
    {
      wx.showToast({
        title: '输入错误',
        icon: 'loading',
        duration: 1000
      })
    }
  }
})